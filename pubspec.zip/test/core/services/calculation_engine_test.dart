import 'package:easy_four_diy/core/services/calculation_engine.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('PDF material and professional cost calculations', () {
    test('wallpaper uses C materials for DIY and P materials plus labour', () {
      final result = CalculationEngine.calculate(
        length: 1,
        width: 1,
        height: 0,
        isPainting: false,
        isBehangen: true,
        includeExtra: false,
      );

      expect(result.materialCost, closeTo(7.00, 0.001));
      expect(result.outsourcingCost, closeTo(16.25, 0.001));
      expect(result.savings, closeTo(9.25, 0.001));
      expect(result.laborCost, 0);
    });

    test('laminate uses separate C and P material prices', () {
      final result = CalculationEngine.calculate(
        length: 1,
        width: 1,
        height: 0,
        isPainting: false,
        isLaminaat: true,
        includeExtra: false,
      );

      expect(result.materialCost, closeTo(26.00, 0.001));
      expect(result.outsourcingCost, closeTo(27.75, 0.001));
      expect(result.savings, closeTo(1.75, 0.001));
    });

    test('painting uses PDF material prices and trade rate', () {
      final result = CalculationEngine.calculate(
        length: 1,
        width: 1,
        height: 0,
        isPainting: true,
        includeExtra: false,
      );

      expect(result.materialCost, closeTo(4.50, 0.001));
      expect(result.outsourcingCost, closeTo(7.50, 0.001));
      expect(result.savings, closeTo(3.00, 0.001));
    });

    test('paving preserves a negative saving when DIY materials cost more', () {
      final result = CalculationEngine.calculate(
        length: 1,
        width: 1,
        height: 0,
        isPainting: false,
        isTerras: true,
        includeExtra: false,
      );

      expect(result.materialCost, closeTo(43.00, 0.001));
      expect(result.outsourcingCost, closeTo(42.00, 0.001));
      expect(result.savings, closeTo(-1.00, 0.001));
    });

    test('artificial grass uses P materials plus gardener labour', () {
      final result = CalculationEngine.calculate(
        length: 1,
        width: 1,
        height: 0,
        isPainting: false,
        isArtificialGrass: true,
        includeExtra: false,
      );

      expect(result.materialCost, closeTo(38.00, 0.001));
      expect(result.outsourcingCost, closeTo(31.00, 0.001));
      expect(result.savings, closeTo(-7.00, 0.001));
    });

    test('tile and grout calculations use distinct material prices', () {
      final floorTiles = CalculationEngine.calculate(
        length: 1,
        width: 1,
        height: 0,
        isPainting: false,
        isTiler: true,
        includeExtra: false,
      );
      final grout = CalculationEngine.calculate(
        length: 1,
        width: 1,
        height: 0,
        isPainting: false,
        isTiler: true,
        isTilerGrouting: true,
        includeExtra: false,
      );

      expect(floorTiles.materialCost, closeTo(31.90, 0.001));
      expect(floorTiles.outsourcingCost, closeTo(44.40, 0.001));
      expect(floorTiles.savings, closeTo(12.50, 0.001));
      expect(grout.materialCost, closeTo(1.20, 0.001));
      expect(grout.outsourcingCost, closeTo(5.30, 0.001));
      expect(grout.savings, closeTo(4.10, 0.001));
    });

    test('wall tiles, drywall, and canopy use P materials in pro totals', () {
      final wallTiles = CalculationEngine.calculate(
        length: 1,
        width: 1,
        height: 0,
        isPainting: false,
        isTiler: true,
        isTilerWall: true,
        includeExtra: false,
      );
      final drywall = CalculationEngine.calculate(
        length: 1,
        width: 0,
        height: 1,
        isPainting: false,
        isGipswand: true,
        includeExtra: false,
      );
      final canopy = CalculationEngine.calculate(
        length: 1,
        width: 1,
        height: 0,
        isPainting: false,
        isOverkapping: true,
        includeExtra: false,
      );

      expect(wallTiles.materialCost, closeTo(49.50, 0.001));
      expect(wallTiles.outsourcingCost, closeTo(52.00, 0.001));
      expect(wallTiles.savings, closeTo(2.50, 0.001));
      expect(drywall.materialCost, closeTo(25.00, 0.001));
      expect(drywall.outsourcingCost, closeTo(31.85, 0.001));
      expect(drywall.savings, closeTo(6.85, 0.001));
      expect(canopy.materialCost, closeTo(122.00, 0.001));
      expect(canopy.outsourcingCost, closeTo(147.00, 0.001));
      expect(canopy.savings, closeTo(25.00, 0.001));
    });

    test('area-based reserve is applied consistently to C and P materials', () {
      final result = CalculationEngine.calculate(
        length: 1,
        width: 1,
        height: 0,
        isPainting: true,
      );

      expect(result.materialCost, closeTo(4.95, 0.001));
      expect(result.outsourcingCost, closeTo(7.80, 0.001));
      expect(result.savings, closeTo(2.85, 0.001));
    });
  });
}
