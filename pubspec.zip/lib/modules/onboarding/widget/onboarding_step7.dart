import 'package:easy_four_diy/core/utils.dart';
import 'package:easy_four_diy/l10n/app_localizations.dart';
import 'package:easy_four_diy/modules/onboarding/onboarding_provider.dart';
import 'package:flutter/material.dart';

class OnboardingStep7 extends StatelessWidget {
  final OnboardingProvider provider;
  final AppLocalizations l10n;
  const OnboardingStep7({
    super.key,
    required this.provider,
    required this.l10n,
  });

  @override
  Widget build(BuildContext context) {
    final calc = provider.calcResult;

    return Column(
      children: [
        const SizedBox(height: 20),
        Text(
          l10n.onboardingCostOverview,
          style: Utils.getTextStyle(
            baseSize: 22,
            isBold: true,
            color: Utils.kDarkBlue,
          ),
        ),
        Text(
          l10n.onboardingCostDiy,
          style: Utils.getTextStyle(
            baseSize: 10,
            isBold: false,
            color: Colors.grey,
          ),
        ),
        const SizedBox(height: 20),
        Row(
          children: [
            Expanded(
              child: _buildCostCard(
                l10n.onboardingDoItYourself,
                l10n.dashboardMaterials,
                '€ ${calc?.materialCost.toStringAsFixed(2) ?? "0.00"}',
                l10n.dashboardTimeEstimate,
                '${Utils.formatHours(calc?.klusserHours)} ${l10n.dashboardHours}',
                l10n.dashboardTotal,
                '€ ${calc?.materialCost.toStringAsFixed(2) ?? "0.00"}',
                false,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _buildCostCard(
                l10n.onboardingHireProfessional,
                l10n.onboardingAveragePrice,
                '€ ${calc?.outsourcingCost.toStringAsFixed(2) ?? "0.00"}',
                l10n.dashboardTimeEstimate,
                '${Utils.formatHours(calc?.proHours)} ${l10n.dashboardHours}',
                '',
                '',
                true,
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.green[900],
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      l10n.onboardingYouSave,
                      style: Utils.getTextStyle(
                        baseSize: 12,
                        isBold: false,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      '€ ${calc?.savings.toStringAsFixed(2) ?? "0.00"}',
                      style: Utils.getTextStyle(
                        baseSize: 24,
                        isBold: false,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      '(${calc?.savingsPercent ?? 0}%) ${l10n.onboardingSmartDiy}',
                      style: Utils.getTextStyle(
                        baseSize: 10,
                        isBold: false,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(Icons.savings, color: Colors.greenAccent, size: 40),
            ],
          ),
        ),
        const SizedBox(height: 16),
        _buildGuidancePanel(provider),
      ],
    );
  }

  Widget _buildGuidancePanel(OnboardingProvider provider) {
    final tradeGuidance = switch (provider.selectedJobId) {
      'carpenter' => l10n.doc5GuidanceCarpenter,
      'painter' => l10n.doc5GuidancePainter,
      'plumber' => l10n.doc5GuidancePlumber,
      'gardener' => l10n.doc5GuidanceGardener,
      'electrician' => l10n.doc5GuidanceElectrician,
      'tiler' => l10n.doc5GuidanceTiler,
      _ => l10n.doc5SafetyNote,
    };

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF8E1),
        border: Border.all(color: const Color(0xFFFFCC80)),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            l10n.doc5GuidanceTitle,
            style: Utils.getTextStyle(
              baseSize: 14,
              isBold: true,
              color: Utils.kDarkBlue,
            ),
          ),
          const SizedBox(height: 10),
          _buildGuidanceLine(
            l10n.doc5RuleMostCommonMaterial,
            l10n.doc5RuleMostCommonMaterialDesc,
          ),
          _buildGuidanceLine(
            l10n.doc5RuleAveragePrice,
            '${l10n.doc5RuleAveragePriceDesc} ${l10n.doc5CostNote}',
          ),
          _buildGuidanceLine(
            l10n.doc5RuleNoUnnecessaryMaterials,
            l10n.doc5RuleNoUnnecessaryMaterialsDesc,
          ),
          _buildGuidanceLine(
            l10n.doc5RuleOptionalMaterials,
            l10n.doc5RuleOptionalMaterialsDesc,
          ),
          _buildGuidanceLine(
            l10n.doc5RuleManufacturerFirst,
            l10n.doc5RuleManufacturerFirstDesc,
          ),
          _buildGuidanceLine(
            l10n.doc5RuleSituationCheck,
            l10n.doc5RuleSituationCheckDesc,
          ),
          _buildGuidanceLine(
            l10n.doc5HourIndicationTitle,
            '${l10n.doc5HoursNote} ${l10n.doc5HourIndicationDisclaimer}',
          ),
          _buildGuidanceLine(
            l10n.doc5TestTitle,
            '${l10n.doc5TestLevel}; ${l10n.doc5TestSecure}; '
            '${l10n.doc5TestFunction}; ${l10n.doc5TestFinish}.',
          ),
          _buildGuidanceLine(l10n.doc5SafetyNote, tradeGuidance),
        ],
      ),
    );
  }

  Widget _buildGuidanceLine(String title, String description) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: RichText(
        text: TextSpan(
          style: const TextStyle(fontSize: 11, color: Colors.black87),
          children: [
            TextSpan(
              text: '$title: ',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            TextSpan(text: description),
          ],
        ),
      ),
    );
  }
}

Widget _buildCostCard(
  String title,
  String label1,
  String val1,
  String label2,
  String val2,
  String label3,
  String val3,
  bool isHighlighted,
) {
  return Container(
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(
      color: isHighlighted
          ? Utils.kOrange.withValues(alpha: 0.05)
          : Colors.white,
      border: Border.all(
        color: isHighlighted ? Utils.kOrange : Utils.kLightGrey,
      ),
      borderRadius: BorderRadius.circular(12),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: Utils.getTextStyle(
            baseSize: 10,
            isBold: false,
            color: isHighlighted ? Utils.kOrange : Colors.grey,
          ),
        ),
        const SizedBox(height: 12),
        Text(label1, style: const TextStyle(fontSize: 10, color: Colors.grey)),
        Text(
          val1,
          style: Utils.getTextStyle(
            baseSize: 14,
            isBold: false,
            color: Utils.kDarkBlue,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          label2,
          style: Utils.getTextStyle(
            baseSize: 10,
            isBold: false,
            color: Utils.kDarkBlue,
          ),
        ),
        Text(
          val2,
          style: Utils.getTextStyle(
            baseSize: 14,
            isBold: false,
            color: Utils.kDarkBlue,
          ),
        ),
        if (label3.isNotEmpty) ...[
          const SizedBox(height: 8),
          Text(
            label3,
            style: Utils.getTextStyle(
              baseSize: 10,
              isBold: false,
              color: Utils.kDarkBlue,
            ),
          ),
          Text(
            val3,
            style: Utils.getTextStyle(
              baseSize: 14,
              isBold: false,
              color: Utils.kDarkBlue,
            ),
          ),
        ],
      ],
    ),
  );
}
